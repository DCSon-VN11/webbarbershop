<?php
    include_once('control.php');
    $get=new data();
if(isset($_GET['nv']))
{
    $id=$_GET['nv'];
    $se=$get->se_tk_nv_id($id);
    foreach($se as $r)
    unlink("../assets/images/nhanvien/".$r['anhtaikhoan']);
    $del=$get->del_tk_nv($id);
}
if(isset($_GET['ch'])){
    $id=$_GET['ch'];
    $del=$get->del_ch($id);
}
if ($del) echo "<script>alert('Thành công')</script>";
else echo "<script>alert('Không thành công')</script>";
if(isset($_GET['nv'])) echo "<script>window.location='../nhanvien.php';</script>";
if(isset($_GET['ch'])) echo "<script>window.location='../cuahang.php';</script>";
?>