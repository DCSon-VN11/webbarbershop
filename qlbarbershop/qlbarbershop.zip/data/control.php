<?php
include('connect.php');

session_start();
class data
{
    function login($tendn, $mk)
    {
        global $conn;
        $sql = "select * from taikhoan where taikhoan='$tendn' and matkhau = '$mk'";
        $run = mysqli_query($conn, $sql);
        return $run;
    }
    function se_tk()
    {
        global $conn;
        $sql = "select * from taikhoan";
        $run = mysqli_query($conn, $sql);
        return $run;
    }
    function doimk($mk, $id)
    {
        global $conn;
        $sql = "UPDATE taikhoan SET matkhau = '$mk' WHERE ID_TK = '$id'";
        $run = mysqli_query($conn, $sql);
        return $run;
    }
    //----------NHÂN VIÊN----------//
    function se_tk_nv()
    {
        global $conn;
        $sql = "select * from taikhoan where level = 1";
        $run = mysqli_query($conn, $sql);
        return $run;
    }
    function se_tk_nv_id($id)
    {
        global $conn;
        $sql = "select * from taikhoan where taikhoan='$id'";
        $run = mysqli_query($conn, $sql);
        return $run;
    }
    function in_tk_nv($idnv, $ten, $anhnv, $sdt, $ngaysinh, $gioitinh, $diachi)
    {
        global $conn;
        $sql = "insert into taikhoan(taikhoan,matkhau,hoten,anhtaikhoan,sdt,ngaysinh,gioitinh,diachi,level) 
            values ('$idnv','123456','$ten','$anhnv','$sdt','$ngaysinh','$gioitinh','$diachi','1')";
        $run = mysqli_query($conn, $sql);
        return $run;
    }
    function del_tk_nv($id)
    {
        global $conn;
        $sql = "delete from taikhoan where ID_TK='$id' and level= 1";
        $run = mysqli_query($conn, $sql);
        return $run;
    }
    function up_tk_nv($id, $tk, $ten,$anh,$sdt,$ngay,$gioitinh,$diachi)
    {
        global $conn;
        $sql = "UPDATE taikhoan SET taikhoan='$tk',hoten='$ten',anhtaikhoan='$anh',sdt='$sdt',ngaysinh='$ngay',gioitinh='$gioitinh',diachi='$diachi'   WHERE ID_TK = '$id'";
        $run = mysqli_query($conn, $sql);
        return $run;
    }
    //----------CỬA HÀNG----------//
    function in_ch($chinhanh, $diachi)
    {
        global $conn;
        $sql = "insert into cuahang(chinhanh,diachi) values ('$chinhanh','$diachi')";
        $run = mysqli_query($conn, $sql);
        return $run;
    }
    function se_ch()
    {
        global $conn;
        $sql = "select * from cuahang";
        $run = mysqli_query($conn, $sql);
        return $run;
    }
    function del_ch($id)
    {
        global $conn;
        $sql = "delete from cuahang where ID_CH='$id' ";
        $run = mysqli_query($conn, $sql);
        return $run;
    }
    function up_ch($id,$cn,$diachi)
    {
        global $conn;
        $sql = "UPDATE cuahang SET chinhanh='$cn',diachi='$diachi'   WHERE ID_CH = '$id'";
        $run = mysqli_query($conn, $sql);
        return $run;
    }
    //----------DỊCH VỤ----------//
    function in_dv($dv,$gia,$chitiet,$iddm,$idha){
        global $conn;
        $sql = "insert into dichvu(dichvu,gia,chitiet,ID_DM,ID_HA) values ('$dv', '$gia', '$chitiet','$iddm', '$idha')";
        $run = mysqli_query($conn, $sql);
        return $run;
    }
    //----------DANH MỤC----------//
    function in_dm($dm){
        global $conn;
        $sql = "insert into danhmuc(danhmuc) values ('$dm')";
        $run = mysqli_query($conn, $sql);
        return $run;
    }
    //----------HÌNH ẢNH----------//
    function in_ha($ha,$iddv){
        global $conn;
        $sql = "insert into hinhanh(hinhanh, ID_DV) VALUES ('$ha','$iddv')";
        $run = mysqli_query($conn, $sql);
        return $run;
    }
}