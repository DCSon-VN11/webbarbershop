<?php
include('data/control.php');
if (!isset($_SESSION['tk'])) {
    echo "<script>alert('Bạn chưa đăng nhập!!!')</script>";
    echo "<script>window.location='login.php';</script>";
} else
    $tk = $_SESSION['tk'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Upvex - Responsive Admin Dashboard Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description">
    <meta content="Coderthemes" name="author">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/ThoiTrangToc-020.jpg">

    <!-- third party css -->
    <link href="assets\libs\datatables\dataTables.bootstrap4.css" rel="stylesheet" type="text/css">
    <link href="assets\libs\datatables\responsive.bootstrap4.css" rel="stylesheet" type="text/css">
    <link href="assets\libs\datatables\buttons.bootstrap4.css" rel="stylesheet" type="text/css">
    <link href="assets\libs\datatables\select.bootstrap4.css" rel="stylesheet" type="text/css">
    <!-- third party css end -->
    <!-- App css -->
    <link href="assets\css\bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="assets\css\icons.min.css" rel="stylesheet" type="text/css">
    <link href="assets\css\app.min.css" rel="stylesheet" type="text/css">
    <link href="assets\css\main.css" rel="stylesheet" type="text/css">
</head>

<body onload="time()" class="left-side-menu-light topbar-dark">
    <!-- Begin page -->
    <div id="wrapper">
        <!-- Topbar Start -->
        <div class="navbar-custom">
            <ul class="list-unstyled topnav-menu float-right mb-0">
                <li class="dropdown notification-list">
                    <a class="nav-link dropdown-toggle nav-user mr-0 waves-effect waves-light" data-toggle="dropdown"
                        href="#" role="button" aria-haspopup="false" aria-expanded="false">
                        <img <?php if ($tk['level'] == 0) { ?> src="assets\images\users\user.jpg" <?php } else { ?>
                                src="assets\images\nhanvien/<?php echo $tk['anhtaikhoan'] ?>" <?php } ?> alt="user-image"
                            class="rounded-circle">
                        <span class="pro-user-name ml-1">
                            <?php echo $tk['hoten'] ?> <i class="mdi mdi-chevron-down"></i>
                        </span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                        <!-- item-->
                        <div class="dropdown-item noti-title">
                            <h5 class="m-0 text-white">
                                <?php 
                                    if($tk['level'] == 0) echo "Admin";
                                    else echo "Quản trị viên";
                                ?>
                            </h5>
                        </div>
                        <div class="dropdown-divider"></div>
                        <!-- item-->
                        <a href="doimk.php" class="dropdown-item notify-item">
                            <i class="la la-key"></i>
                            <span>Đổi mật khẩu</span>
                        </a>
                        <a href="logout.php" class="dropdown-item notify-item">
                            <i class="fe-log-out"></i>
                            <span>Đăng xuất</span>
                        </a>
                    </div>
                </li>
            </ul>
            <!-- LOGO -->
            <div class="logo-box">
                <a href="index.php" class="logo text-center">
                    <span class="logo-lg">
                        <img src="assets\images\logo.png" alt="" height="24">
                        <!-- <span class="logo-lg-text-light">Upvex</span> -->
                    </span>
                    <span class="logo-sm">
                        <!-- <span class="logo-sm-text-dark">X</span> -->
                        <img src="assets/images/ThoiTrangToc-020.jpg" alt="" height="28">
                    </span>
                </a>
            </div>
            <ul class="list-unstyled topnav-menu topnav-menu-left m-0">
                <li>
                    <button class="button-menu-mobile waves-effect waves-light">
                        <i class="icon-menu"></i>
                    </button>
                </li>
            </ul>
        </div>
        <!-- end Topbar -->
        <!-- ========== Left Sidebar Start ========== -->
        <div class="left-side-menu">
            <!--- Sidemenu -->
            <div id="sidebar-menu">

                <ul class="metismenu" id="side-menu">

                    <li>
                        <a href="index.php">
                            <i class="icon-speedometer"></i>
                            <span> Bảng điều khiển </span>
                        </a>
                    </li>
                    <li>
                        <a <?php
                        if ($tk['level'] == 0) { ?> href="nhanvien.php" <?php } else { ?>
                                onclick="return alert('Bạn không có quyền truy cập!!!')" <?php } ?>>
                            <i class="icon-people"></i>
                            <span> Quản lý Nhân viên</span>
                        </a>
                    </li>
                    <li>
                        <a href="khachhang.php">
                            <i class="icon-user"></i>
                            <span> Quản lý Khách hàng </span>
                        </a>
                    </li>

                    <li>
                        <a href="dichvu.php">
                            <i class=" icon-layers"></i>
                            <span> Quản lý Dịch vụ </span>
                        </a>
                    </li>

                    <li>
                        <a href="datlich.php">
                            <i class="icon-basket"></i>
                            <span> Quản lý Đặt lịch </span>
                        </a>
                    </li>

                    <li>
                        <a <?php
                        if ($tk['level'] == 0) { ?> href="cuahang.php" <?php } else { ?>
                                onclick="return alert('Bạn không có quyền truy cập!!!')" <?php } ?>>
                            <i class="icon-home"></i>
                            <span> Quản lý Cửa hàng </span>
                        </a>
                    </li>

                    <li>
                        <a href="thongke.php">
                            <i class="icon-pie-chart"></i>
                            <span> Thống kê </span>
                        </a>
                    </li>
                </ul>
            </div>
            <!-- End Sidebar -->
            <div class="clearfix"></div>
            <!-- Sidebar -left -->
        </div>
        <!-- Left Sidebar End -->
        <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->
        <div class="content-page">
            <div class="content">

                <!-- Start Content-->
                <div class="container-fluid">

                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <div id="clock"></div>
                                    </ol>
                                </div>
                                <h4 class="page-title">Bảng điều khiển</h4>
                            </div>
                        </div>
                    </div>
                    <!-- end page title -->
                    <div class="row">
                        <div class="col-md-6 col-lg-3">
                            <div class="widget-small warning coloured-icon"><i class='icon fa-3x icon-bag'></i>
                                <div class="info">
                                    <h4 style="font-size: 20px;">Đơn hàng</h4>
                                    <p><b>457 đơn hàng</b></p>
                                    <p class="float-right text-muted mb-0">Trong ngày</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-3">
                            <div class="widget-small primary coloured-icon"><i class='icon fa-3x icon-credit-card'></i>
                                <div class="info">
                                    <h4 style="font-size: 20px;">Thu nhập</h4>
                                    <p><b>104.890.000 đ</b></p>
                                    <p class="float-right text-muted mb-0">Trong ngày</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-3">
                            <div class="widget-small info coloured-icon"><i class='icon fa-3x fas fa-user'></i>
                                <div class="info">
                                    <h4 style="font-size: 20px;">Khách hàng</h4>
                                    <p><b>3 khách hàng</b></p>
                                    <p class="float-right text-muted mb-0">Trong ngày</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-3">
                            <div class="widget-small primary coloured-icon"><i class='icon  fas fa-users fa-3x'></i>
                                <div class="info">
                                    <h4 style="font-size: 20px;">Nhân viên</h4>
                                    <p><b>26 nhân viên</b></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-xl-6">
                            <!-- Portlet card -->
                            <div class="card">
                                <div class="card-body">
                                    <div class="card-widgets">
                                        <a href="javascript: void(0);" data-toggle="reload"><i
                                                class="mdi mdi-refresh"></i></a>
                                        <a data-toggle="collapse" href="#cardCollpase1" role="button"
                                            aria-expanded="false" aria-controls="cardCollpase1"><i
                                                class="mdi mdi-minus"></i></a>
                                        <a href="javascript: void(0);" data-toggle="remove"><i
                                                class="mdi mdi-close"></i></a>
                                    </div>
                                    <h4 class="header-title mb-0">Thống kê Doanh thu
                                        <script type="text/javascript">
                                            document.write(new Date().getFullYear());
                                        </script>
                                    </h4>

                                    <div id="cardCollpase1" class="collapse pt-3 show" dir="ltr">
                                        <canvas id="myChart"></canvas>
                                        <div class="text-center">
                                            <div class="row mt-3">
                                                <div class="col-4">
                                                    <p class="text-muted font-15 mb-1 text-truncate">Target</p>
                                                    <h4><i class="fe-arrow-down text-danger mr-1"></i>$7.8k</h4>
                                                </div>
                                                <div class="col-4">
                                                    <p class="text-muted font-15 mb-1 text-truncate">Last week</p>
                                                    <h4><i class="fe-arrow-up text-success mr-1"></i>$1.4k</h4>
                                                </div>
                                                <div class="col-4">
                                                    <p class="text-muted font-15 mb-1 text-truncate">Last Month</p>
                                                    <h4><i class="fe-arrow-down text-danger mr-1"></i>$9.8k</h4>
                                                </div>
                                            </div> <!-- end row -->

                                        </div>
                                    </div> <!-- collapsed end -->
                                </div> <!-- end card-body -->
                            </div> <!-- end card-->
                        </div> <!-- end col-->

                        <div class="col-xl-6">
                            <div class="card">
                                <div class="card-body">
                                    <div class="card-widgets">
                                        <a href="javascript: void(0);" data-toggle="reload"><i
                                                class="mdi mdi-refresh"></i></a>
                                        <a data-toggle="collapse" href="#cardCollpase2" role="button"
                                            aria-expanded="false" aria-controls="cardCollpase2"><i
                                                class="mdi mdi-minus"></i></a>
                                        <a href="javascript: void(0);" data-toggle="remove"><i
                                                class="mdi mdi-close"></i></a>
                                    </div>
                                    <h4 class="header-title mb-0">Doanh thu Chi nhánh</h4>

                                    <div id="cardCollpase2" class="collapse pt-3 show" dir="ltr">
                                        <canvas id="myChart1"></canvas>
                                        <div class="text-center">
                                            <div class="row mt-3">
                                                <div class="col-4">
                                                    <p class="text-muted font-15 mb-1 text-truncate">Target</p>
                                                    <h4><i class="fe-arrow-up text-success mr-1"></i>641</h4>
                                                </div>
                                                <div class="col-4">
                                                    <p class="text-muted font-15 mb-1 text-truncate">Last week</p>
                                                    <h4><i class="fe-arrow-down text-danger mr-1"></i>234</h4>
                                                </div>
                                                <div class="col-4">
                                                    <p class="text-muted font-15 mb-1 text-truncate">Last Month</p>
                                                    <h4><i class="fe-arrow-up text-success mr-1"></i>3201</h4>
                                                </div>
                                            </div> <!-- end row -->
                                        </div>
                                    </div> <!-- collapsed end -->
                                </div> <!-- end card-body -->
                            </div> <!-- end card-->
                        </div> <!-- end col-->
                    </div>
                    <!-- end row -->
                    <div class="col-xl-12">
                        <div class="card-box">
                            <h4 class="header-title mb-3">Đơn đặt lịch mới</h4>

                            <div class="table-responsive">
                                <table class="table table-centered table-borderless table-hover table-nowrap mb-0"
                                    id="datatable">
                                    <thead class="thead-light">
                                        <tr>
                                            <th class="border-top-0">Name</th>
                                            <th class="border-top-0">Card</th>
                                            <th class="border-top-0">Date</th>
                                            <th class="border-top-0">Amount</th>
                                            <th class="border-top-0">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <img src="assets\images\users\user-2.jpg" alt="user-pic"
                                                    class="rounded-circle avatar-sm">
                                                <span class="ml-2">Imelda J. Stanberry</span>
                                            </td>
                                            <td>
                                                <img src="assets\images\cards\visa.png" alt="user-card" height="24">
                                                <span class="ml-2">**** 3256</span>
                                            </td>
                                            <td>27.03.2018</td>
                                            <td>$345.98</td>
                                            <td><span class="badge badge-pill badge-danger">Failed</span></td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <img src="assets\images\users\user-3.jpg" alt="user-pic"
                                                    class="rounded-circle avatar-sm">
                                                <span class="ml-2">Francisca S. Lobb</span>
                                            </td>
                                            <td>
                                                <img src="assets\images\cards\master.png" alt="user-card" height="24">
                                                <span class="ml-2">**** 8451</span>
                                            </td>
                                            <td>28.03.2018</td>
                                            <td>$1,250</td>
                                            <td><span class="badge badge-pill badge-success">Paid</span></td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <img src="assets\images\users\user-4.jpg" alt="user-pic"
                                                    class="rounded-circle avatar-sm">
                                                <span class="ml-2">James A. Wert</span>
                                            </td>
                                            <td>
                                                <img src="assets\images\cards\amazon.png" alt="user-card" height="24">
                                                <span class="ml-2">**** 2258</span>
                                            </td>
                                            <td>28.03.2018</td>
                                            <td>$145</td>
                                            <td><span class="badge badge-pill badge-success">Paid</span></td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <img src="assets\images\users\user-5.jpg" alt="user-pic"
                                                    class="rounded-circle avatar-sm">
                                                <span class="ml-2">Dolores J. Pooley</span>
                                            </td>
                                            <td>
                                                <img src="assets\images\cards\american-express.png" alt="user-card"
                                                    height="24">
                                                <span class="ml-2">**** 6950</span>
                                            </td>
                                            <td>29.03.2018</td>
                                            <td>$2,005.89</td>
                                            <td><span class="badge badge-pill badge-danger">Failed</span></td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <img src="assets\images\users\user-5.jpg" alt="user-pic"
                                                    class="rounded-circle avatar-sm">
                                                <span class="ml-2">Karen I. McCluskey</span>
                                            </td>
                                            <td>
                                                <img src="assets\images\cards\discover.png" alt="user-card" height="24">
                                                <span class="ml-2">**** 0021</span>
                                            </td>
                                            <td>31.03.2018</td>
                                            <td>$24.95</td>
                                            <td><span class="badge badge-pill badge-success">Paid</span></td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <img src="assets\images\users\user-6.jpg" alt="user-pic"
                                                    class="rounded-circle avatar-sm">
                                                <span class="ml-2">Kenneth J. Melendez</span>
                                            </td>
                                            <td>
                                                <img src="assets\images\cards\visa.png" alt="user-card" height="24">
                                                <span class="ml-2">**** 2840</span>
                                            </td>
                                            <td>27.03.2018</td>
                                            <td>$345.98</td>
                                            <td><span class="badge badge-pill badge-success">Paid</span></td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <img src="assets\images\users\user-7.jpg" alt="user-pic"
                                                    class="rounded-circle avatar-sm">
                                                <span class="ml-2">Sandra M. Nicholas</span>
                                            </td>
                                            <td>
                                                <img src="assets\images\cards\master.png" alt="user-card" height="24">
                                                <span class="ml-2">**** 2015</span>
                                            </td>
                                            <td>28.03.2018</td>
                                            <td>$1,250</td>
                                            <td><span class="badge badge-pill badge-danger">Failed</span></td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <img src="assets\images\users\user-8.jpg" alt="user-pic"
                                                    class="rounded-circle avatar-sm">
                                                <span class="ml-2">Ronald S. Taylor</span>
                                            </td>
                                            <td>
                                                <img src="assets\images\cards\amazon.png" alt="user-card" height="24">
                                                <span class="ml-2">**** 0325</span>
                                            </td>
                                            <td>28.03.2018</td>
                                            <td>$145</td>
                                            <td><span class="badge badge-pill badge-success">Paid</span></td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <img src="assets\images\users\user-9.jpg" alt="user-pic"
                                                    class="rounded-circle avatar-sm">
                                                <span class="ml-2">Beatrice L. Iacovelli</span>
                                            </td>
                                            <td>
                                                <img src="assets\images\cards\discover.png" alt="user-card" height="24">
                                                <span class="ml-2">**** 9058</span>
                                            </td>
                                            <td>29.03.2018</td>
                                            <td>$6,542.32</td>
                                            <td><span class="badge badge-pill badge-success">Paid</span></td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <img src="assets\images\users\user-10.jpg" alt="user-pic"
                                                    class="rounded-circle avatar-sm">
                                                <span class="ml-2">Sylvia H. Parker</span>
                                            </td>
                                            <td>
                                                <img src="assets\images\cards\discover.png" alt="user-card" height="24">
                                                <span class="ml-2">**** 2577</span>
                                            </td>
                                            <td>31.03.2018</td>
                                            <td>$24.95</td>
                                            <td><span class="badge badge-pill badge-danger">Failed</span></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div> <!-- end table-responsive -->

                        </div> <!-- end card-box-->
                    </div> <!-- end col-->

                </div>
                <!-- end row -->

            </div> <!-- container -->

        </div> <!-- content -->

        <!-- Footer Start -->
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6">
                        2019 &copy; Upvex theme by <a href="">Coderthemes</a>
                    </div>
                    <div class="col-md-6">
                        <div class="text-md-right footer-links d-none d-sm-block">
                            <a href="javascript:void(0);">About Us</a>
                            <a href="javascript:void(0);">Help</a>
                            <a href="javascript:void(0);">Contact Us</a>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- end Footer -->

    </div>
    <!-- ============================================================== -->
    <!-- End Page content -->
    <!-- ============================================================== -->
    </div>
    <!-- END wrapper -->
    <script>
        var xValues = ["Tháng 1", "Tháng 2", "Tháng 3", "Tháng 4", "Tháng 5", "Tháng 6", "Tháng 7", "Tháng 8", "Tháng 9", "Tháng 10", "Tháng 11", "Tháng 12"];

        new Chart("myChart", {
            type: "line",
            data: {
                labels: xValues,
                datasets: [{
                    data: [860, 1140, 1060, 1060, 1070, 1110, 1330, 2210, 7830, 2478, 2341, 6546],
                    borderColor: "red", backgroundColor: "red",
                    fill: false
                }, {
                    data: [1600, 1700, 1700, 1900, 2000, 2700, 4000, 5000, 6000, 7000, 6465, 1234],
                    borderColor: "green", backgroundColor: "green",
                    fill: false
                }, {
                    data: [300, 700, 2000, 5000, 6000, 4000, 2000, 1000, 200, 100, 50, 4000],
                    borderColor: "blue", backgroundColor: "blue",
                    fill: false
                }]
            },
            options: {
                legend: { display: false }
            }
        });
    </script>
    <script>
        var xValues = ["Hà Nội", "Bắc Ninh", "TP.Hồ Chí Minh", "Đà Nẵng"];
        var yValues = [55, 49, 44, 24];
        var barColors = ["red", "green", "blue", "orange"];

        new Chart("myChart1", {
            type: "bar",
            data: {
                labels: xValues,
                datasets: [{
                    backgroundColor: barColors,
                    data: yValues
                }]
            },
            options: {
                legend: { display: false },
                title: {
                    display: true,
                }
            }
        });
    </script>
    <script type="text/javascript">
        //Thời Gian
        function time() {
            var today = new Date();
            var weekday = new Array(7);
            weekday[0] = "Chủ Nhật";
            weekday[1] = "Thứ Hai";
            weekday[2] = "Thứ Ba";
            weekday[3] = "Thứ Tư";
            weekday[4] = "Thứ Năm";
            weekday[5] = "Thứ Sáu";
            weekday[6] = "Thứ Bảy";
            var day = weekday[today.getDay()];
            var dd = today.getDate();
            var mm = today.getMonth() + 1;
            var yyyy = today.getFullYear();
            var h = today.getHours();
            var m = today.getMinutes();
            var s = today.getSeconds();
            m = checkTime(m);
            s = checkTime(s);
            nowTime = h + " giờ " + m + " phút " + s + " giây";
            if (dd < 10) {
                dd = '0' + dd
            }
            if (mm < 10) {
                mm = '0' + mm
            }
            today = day + ', ' + dd + '/' + mm + '/' + yyyy;
            tmp = '<span class="date"> ' + today + ' - ' + nowTime +
                '</span>';
            document.getElementById("clock").innerHTML = tmp;
            function checkTime(i) {
                if (i < 10) {
                    i = "0" + i;
                }
                return i;
            }
        }
        setInterval(time, 1000);
    </script>
    <!-- Vendor js -->
    <script src="assets\js\vendor.min.js"></script>

    <!-- Third Party js-->
    <script src="assets\libs\peity\jquery.peity.min.js"></script>
    <script src="assets\libs\apexcharts\apexcharts.min.js"></script>
    <script src="assets\libs\jquery-vectormap\jquery-jvectormap-1.2.2.min.js"></script>
    <script src="assets\libs\jquery-vectormap\jquery-jvectormap-us-merc-en.js"></script>

    <!-- Dashboard init -->
    <script src="assets\js\pages\dashboard-2.init.js"></script>

    <!-- App js -->
    <script src="assets\js\app.min.js"></script>

</body>

</html>